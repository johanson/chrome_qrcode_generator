# URL to QRCode generator

Google Chrome extension to share URLs between desktop and mobile clients by generating QRCode from an active tab.

![Screenshot](screenshots/screenshot-1.png?raw=true)

